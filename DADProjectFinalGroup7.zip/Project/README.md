DAD Project - IST - Group 7
By: David Belchior (95550), João Aragonez (95606), Vasco Correia (94188)
To run: `cd PuppetMaster; dotnet run ../Config/<filename>`
